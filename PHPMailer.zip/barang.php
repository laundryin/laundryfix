<?php include 'koneksi.php'; ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Master Barang - Harum Laundry ERP</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css" rel="stylesheet">
    <style>
        body { font-family: 'Poppins', sans-serif; background-color: #fdf2f8; color: #334155; }
        .sidebar { width: 260px; height: 100vh; position: fixed; background: rgba(255, 255, 255, 0.8); backdrop-filter: blur(10px); border-right: 1px solid #fce7f3; z-index: 100; overflow-y: auto;}
        .sidebar-brand { font-size: 1.8rem; font-weight: 700; background: linear-gradient(90deg, #3b82f6, #ec4899); -webkit-background-clip: text; -webkit-text-fill-color: transparent; padding: 1.5rem; text-align: center; border-bottom: 1px solid #fce7f3; }
        .nav-link { color: #64748b; font-weight: 500; padding: 10px 20px; border-radius: 10px; margin: 4px 15px; transition: 0.3s; font-size: 0.9rem;}
        .nav-link:hover, .nav-link.active { background: linear-gradient(90deg, rgba(59, 130, 246, 0.1), rgba(236, 72, 153, 0.1)); color: #ec4899 !important; border-left: 4px solid #ec4899; }
        .nav-link i { margin-right: 10px; font-size: 1.1rem; }
        .main-content { margin-left: 260px; padding: 40px; }
        .table-custom { background-color: white; border-radius: 20px; overflow: hidden; box-shadow: 0 10px 30px rgba(236, 72, 153, 0.05); }
        .table-custom thead th { background-color: #f8fafc; color: #64748b; font-weight: 600; padding: 15px; border-bottom: 2px solid #f1f5f9; }
        .table-custom td { padding: 15px; vertical-align: middle; border-bottom: 1px solid #f1f5f9; }
        .stok-habis { background-color: #fff1f2 !important; color: #e11d48 !important; }
    </style>
</head>
<body>

    <?php include 'sidebar.php'; ?>

    <div class="main-content">
        <div class="d-flex justify-content-between align-items-center mb-4">
            <h3 class="fw-bold mb-0 d-flex align-items-center gap-2" style="color: #3b82f6;">
                <i class="bi bi-box-seam"></i> Stok Barang
            </h3>
            <a href="tambah_barang.php" class="btn rounded-pill px-4 text-white shadow-sm" style="background: linear-gradient(90deg, #3b82f6, #ec4899); border: none;">
                <i class="bi bi-plus-lg me-2"></i>Tambah Barang
            </a>
        </div>

        <div class="table-custom">
            <table class="table table-hover mb-0">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nama Barang</th>
                        <th>Stok</th>
                        <th>Satuan</th>
                        <th>Harga Beli Avg</th>
                        <th class="text-center">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $query = mysqli_query($conn, "SELECT * FROM barang ORDER BY id_barang DESC");
                    $no = 1; 
                    if(mysqli_num_rows($query) > 0) {
                        while($d = mysqli_fetch_array($query)){
                            $warning = ($d['stok'] <= 5) ? 'stok-habis' : '';
                    ?>
                    <tr class="<?= $warning; ?>">
                        <td class="fw-bold" style="color: #3b82f6;">#<?= $no++; ?></td>
                        <td class="fw-medium"><?= htmlspecialchars($d['nama_barang']); ?></td>
                        <td class="fw-bold"><?= $d['stok']; ?></td>
                        <td><?= htmlspecialchars($d['satuan']); ?></td>
                        <td>Rp <?= number_format($d['harga_beli'], 0, ',', '.'); ?></td>
                        <td class="text-center">
                            <a href="edit_barang.php?id=<?= $d['id_barang']; ?>" class="btn btn-sm btn-outline-primary rounded-pill px-3">Edit</a>
                            <a href="hapus_barang.php?id=<?= $d['id_barang']; ?>" class="btn btn-sm btn-outline-danger rounded-pill px-3" onclick="return confirm('Hapus barang ini dari gudang?')">Hapus</a>
                        </td>
                    </tr>
                    <?php 
                        } 
                    } else { ?>
                    <tr><td colspan="6" class="text-center py-4">Gudang kosong melompong, Wan. Kulakan dulu sana!</td></tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>

</body>
</html>